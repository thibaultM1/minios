<?php

$parameters = [
    'domaine' => '/phpform/all/Projet/Framework/web/app.php',
    'pdo' => [
        'database_host'     => 'localhost',
        'database_name'     => 'minios',
        'database_user'     => 'root',
        'database_password' => '',
    ],
];

