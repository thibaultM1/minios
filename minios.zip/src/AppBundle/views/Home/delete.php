<?php include __DIR__ . '/../top.php'; ?>

<div class="container">
    <div class="col-md-12">
        id: <?php echo $id; ?>
    </div>
</div>

<?php include __DIR__ . '/../bottom.php'; ?>
