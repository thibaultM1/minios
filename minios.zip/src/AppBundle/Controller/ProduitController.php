<?php

namespace AppBundle\Controller;

use Framework\Controller;

class ProduitController extends Controller
{

}
