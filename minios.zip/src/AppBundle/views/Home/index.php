<?php include __DIR__ . '/../top.php'; ?>

<div class="container">
    <div class="col-md-12">
        <!-- Main component for a primary marketing message or call to action -->
        <div class="jumbotron">
            <h1>Mon site</h1>

            <p>Mon texte</p>

            <p>
                <a class="btn btn-lg btn-primary" href="../../components/#navbar" role="button">Bouton !!
                    &raquo;</a>
            </p>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../bottom.php'; ?>
