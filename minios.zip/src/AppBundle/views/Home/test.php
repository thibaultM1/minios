<?php include __DIR__ . '/../top.php'; ?>

<div class="container">
    <div class="col-md-12">
        <h2>Test de la page test</h2>



        <a class="btn btn-info" href="<?php echo $path('index'); ?>">Aller sur la page d'accueil</a>
    </div>
</div>

<?php include __DIR__ . '/../bottom.php'; ?>
